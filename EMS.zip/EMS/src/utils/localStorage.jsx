const employee = [
    {
        "id": 1,
        "email" : "employee1@gmail.com",
        "password" : "123",
        "tasks": [
            {
                "active" : true,
                "newTask" : true,
                "completed" : false,
                "failed" : false,
                "taskTitle" : "Update website",
                "taskDescription" : "Revamp the homepage design",
                "taskDate" : "2024-10-12",
                "category" : "Design"
            },
            {
                "active" : false,
                "newTask" : false,
                "completed" : true,
                "failed" : false,
                "taskTitle" : "Client meeting",
                "taskDescription" : "Discuss project requirements",
                "taskDate" : "2024-10-11",
                "category" : "Meeting"
            },
            {
                "active" : true,
                "newTask" : false,
                "completed" : false,
                "failed" : false,
                "taskTitle" : "Fix bugs",
                "taskDescription" : "Resolve bugs reported in issue tracker",
                "taskDate" : "2024-10-14",
                "category" : "Development"
            },
            {
                "active" : true,
                "newTask" : true,
                "completed" : false,
                "failed" : false,
                "taskTitle" : "Write Documentation",
                "taskDescription" : "Update the project documentation",
                "taskDate" : "2024-10-13",
                "category" : "Documentation"
            },
            {
                "active" : true,
                "newTask" : false,
                "completed" : false,
                "failed" : false,
                "taskTitle" : "Set up CI/CD",
                "taskDescription" : "Implement continuous integration pipeline",
                "taskDate" : "2024-10-11",
                "category" : "Devops"
            }
        ]
    }
];

const admin = [{
    "id" : 1,
    "email":"admin@example.com",
    "password" : "123"
}];

export const setLocalstorage = ()=>{
    localStorage.setItem(employee,JSON.stringify(employee))
    localStorage.setItem(admin,JSON.stringify(admin))
}
export const getLocalstorage = ()=>{
    const employee = JSON.parse (localStorage.getItem('employee'))
    const admin = JSON.parse (localStorage.getItem('admin'))
    
    console.log(employee);
    
}