import React, { useState } from 'react'

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const submitHandler = (e) => {
        e.preventDefault();
        console.log("Email is ", email);
        console.log("Password is", password);
        setEmail("")
        setPassword("")

    }
    return (
        <div className='flex h-screen w-screen items-center justify-center'>
            <div className='border-2 rounded-xl border-emerald-600 p-20 '>
                <form onSubmit={submitHandler}
                    className='flex flex-col justify-center items-center'>
                    <input value={email}
                        onChange={(e) => {
                            setEmail(e.target.value);
                        }}
                        required className=" outline-none bg-transparent border-2 border-emerald-600 py-3 px-5 text-xl placeholder:text-gray-600 rounded-full" type='text' placeholder='Enter your email' />
                    <input value={password}
                        onChange={(e) => {
                            setPassword(e.target.value);
                        }}
                        required className=" outline-none bg-transparent border-2 border-emerald-600 py-3 px-5 text-xl placeholder:text-gray-600 rounded-full mt-3" type='password' placeholder='Enter your password' />
                    <button className="mt-7 text-white outline-none  hover:bg-emerald-500 py-2 px-8 w-full font-semibold bg-emerald-600 text-lg placeholder:text-gray-600 rounded-full border-none">LogIn</button>
                </form>
            </div>
        </div>
    )
}

export default Login;