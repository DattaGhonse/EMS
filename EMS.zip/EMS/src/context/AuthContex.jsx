import React from 'react'

const AuthContex = ({children}) => {
  return (
    <div>{children}</div>
  )
}

export default AuthContex